"use client"
const loading = () => {
  return (
    <div>loading</div>
  )
}

export default loading