import ChangePassword from "@/components/MyAccount/ChangePassword";
import React from "react";

const page = () => {
  return (
    <div>
      <ChangePassword />
    </div>
  );
};

export default page;
