import AccountSetting from "@/components/AccountSetting/AccountSetting";

import React from "react";

const accountSetting = () => {
  return (
    <div>
      <AccountSetting />
    </div>
  );
};

export default accountSetting;
