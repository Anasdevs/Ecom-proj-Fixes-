import OrderHistory from "@/components/OrderHistory/OrderHistory";
import React from "react";

const page = () => {
  return (
    <div>
      <OrderHistory />
    </div>
  );
};

export default page;
