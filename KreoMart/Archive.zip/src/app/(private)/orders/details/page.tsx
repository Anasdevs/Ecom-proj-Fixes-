import OrderDetail from "@/components/OrderHistory/OrderDetail";
import React from "react";

const page = () => {
  return (
    <div>
      <OrderDetail />
    </div>
  );
};

export default page;
