import OrderPlaced from "@/components/CartOption/OrderPlaced";
import React from "react";

const orderPlaced = () => {
  return (
    <div>
      <OrderPlaced />
    </div>
  );
};

export default orderPlaced;
