
import { ContactSection } from '@/components/Home'
import React from 'react'

const page = () => {
  return (
    <div>
        <ContactSection/>
    </div>
  )
}

export default page