"use client";
import Registration from "@/components/Form/Register/Registration";

const RegisterPage = () => {
  return (
    <>
      <Registration />
    </>
  );
};

export default RegisterPage;
