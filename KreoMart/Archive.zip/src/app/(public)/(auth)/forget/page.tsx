import React from 'react'
import Forget from '@/components/ForgetPassword/Forget'
const page = () => {
  return (
    <div>
        <Forget/>
    </div>
  )
}

export default page