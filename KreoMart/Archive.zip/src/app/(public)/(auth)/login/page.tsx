import Login from "@/components/Form/Login/Login";
import loading from "./loading";
import React from "react";

function LoginPage() {
  return (
    <div>
      <Login />
    </div>
  );
}

export default LoginPage;
