import React from "react";

const ChangeEmail = () => {
  return <div>ChangeEmail verify current email change email</div>;
};

export default ChangeEmail;
