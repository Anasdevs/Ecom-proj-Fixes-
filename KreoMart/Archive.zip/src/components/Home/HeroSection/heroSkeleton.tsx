// import React from "react";

// const heroSkeleton = () => {
//   return (
//     <div className="flex justify-between items-center relative w-[1336px]">
//       <div className="inline-flex flex-col gap-40 justify-center ">
//         <div className="inline-flex flex-col gap-24">
//           <div className="rectangle" />
//           <div className="rectangle-2" />
//         </div>
//         <div className="h-42 bg-gray-300 rounded-md relative w-full" />
//       </div>
//       <div className=" h-680 relative w-681">
//         <div className="bg-gray-300 rounded-full absolute top-37 left-37 w-643 h-643" />
//       </div>
//     </div>
//   );
// };

// export default heroSkeleton;
