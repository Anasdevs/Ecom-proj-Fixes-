// import module and export
export { default as HeroSection } from "./HeroSection/HeroSection";
export { default as OfferSection } from "./OfferSection/OfferSection";
export { default as ContactSection } from "./ContactSection/ContactUs";
export { default as BestCategorysecction } from "./MensCategorySections/MensCategory";
