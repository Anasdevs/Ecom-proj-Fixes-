

export interface Product {
    description: string;
    additionalInfo: string;
    review: string;
  }