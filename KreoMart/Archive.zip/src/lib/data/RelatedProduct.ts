import { slideItem } from "../../../typings";

export const slides: slideItem[] = [
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
     
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
     
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
     
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
     
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
     
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
     
    {
      img: "/assets/Imgrp.png",
      description: "Zip-through hoodie",
      dis_price: "₹120.00",
      price: "₹156.00",
    },
  ];