export interface PRODUCT {
    count: number;
    next: string;
    previous: number | null;
    results: ProductItem[];
  }

  