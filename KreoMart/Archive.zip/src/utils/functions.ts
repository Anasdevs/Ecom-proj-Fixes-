export const checkValidText = (value: string | number | undefined) => {
  return value ? value : null;
};
